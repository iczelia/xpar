/*  Copyright (C) 2022-2026 Kamila Szewczyk

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.  */

#ifndef _SHARDING_H_
#define _SHARDING_H_

#include "common.h"
#include "platform.h"
#include "crc32c.h"

#ifdef HAVE_BLAKE2B
  #include "blake2b.h"
#endif


/*  ============================================================================
    General shared (Vandermonde, Log-time) mode encoding and decoding
    utilities.
    ============================================================================  */
#define MAX_DATA_SHARDS 128
#define MAX_PARITY_SHARDS 64
#define MAX_TOTAL_SHARDS (MAX_DATA_SHARDS + MAX_PARITY_SHARDS)

typedef struct {
  const char * input_name, * output_prefix;
  bool force, quiet, verbose, no_map;
  u8 dshards, pshards;
  /*  INTEGRITY_CRC32C (default) or INTEGRITY_BLAKE2B. With BLAKE2B and
      a non-empty key the shard is authenticated; with BLAKE2B and no
      key the shard gets an unkeyed BLAKE2b-128 hash in place of CRC.  */
  int integrity;
  const u8 * auth_key;
  sz auth_keylen;
} sharded_encoding_options_t;

typedef struct {
  const char * output_file, ** input_files;
  bool force, quiet, verbose, no_map;
  sz n_input_shards;
  const u8 * auth_key;
  sz auth_keylen;
} sharded_decoding_options_t;

/*  v1.x shard header. The version byte selects between three integrity
    modes; all three cover (header[0..16) || body).

      plain  (20 bytes): version=0x01, CRC32C at [16..20).
      hash   (32 bytes): version=0x81, unkeyed BLAKE2b-128 at [16..32).
      auth   (32 bytes): version=0xC1, keyed   BLAKE2b-128 at [16..32).

      [0..4)   magic "XPAS" (Vandermonde) or "XPAL" (Leopard)
      [4]      version byte: low 6 bits = SHARD_VERSION, bit 7 = BLAKE2b,
               bit 6 = keyed (only valid alongside bit 7)
      [5]      dshards
      [6]      pshards
      [7]      shard_number
      [8..16)  total_size (u64 BE)
      [16..20) CRC32C   (plain) or first 4 bytes of BLAKE2b tag (hash/auth)
      [20..32) remainder of BLAKE2b tag (hash/auth only)
      body...

    Shards within one set must all have the same integrity mode.  */
#define SHARD_HEADER_SIZE         20
#define SHARD_HEADER_BLAKE2B_SIZE 32
#define SHARD_VERSION             1
#define SHARD_VERSION_BLAKE2B     0x80
#define SHARD_VERSION_KEYED       0x40
#define SHARD_VERSION_MASK        0x3F
typedef struct {
  bool valid, mapped, auth; u32 crc; u8 * buf;
  u8 shard_number, dshards, pshards;
  sz shard_size, total_size, hdr_size;
#if defined(XPAR_ALLOW_MAPPING)
  xpar_mmap map;
#endif
} sharded_hv_result_t;
static void unmap_shard(sharded_hv_result_t * res) {
  if (res->mapped && res->buf) {
    #if defined(XPAR_ALLOW_MAPPING)
    xpar_unmap(&res->map);
    res->buf = NULL;  res->mapped = false;
    #endif
  } else {
    xpar_free(res->buf);  res->buf = NULL;
  }
}
static u8 * most_frequent(u8 * tab, sz nmemb, sz size) {
  xpar_assert(size < 16);  u8 tmp[16]; sz i, j;
  Fi0(nmemb, 1,
    for (j = i;
         j && xpar_memcmp(&tab[j * size], &tab[(j - 1) * size], size) < 0;
         j--) {
      xpar_memcpy(tmp, tab + j * size, size);
      xpar_memcpy(tab + j * size, tab + (j - 1) * size, size);
      xpar_memcpy(tab + (j - 1) * size, tmp, size);
    }
  )
  u8 * best = tab;  sz best_count = 1, current_count = 1;
  Fi0(nmemb, 1,
    if (!xpar_memcmp(tab + i * size, tab + (i - 1) * size, size))
      current_count++;
    else {
      if (current_count > best_count)
        best = tab + (i - 1) * size, best_count = current_count;
      current_count = 1;
    }
  )
  return best;
}

/*  Extract fields from a shard header at the start of `buf`. Detects
    the integrity mode from the version byte (CRC32C, BLAKE2b unkeyed
    hash, or keyed MAC), verifies the tag, and populates `res`. Returns
    true iff the version is supported, the tag matches, and the file's
    keyed-flag agrees with the caller's `opt.auth_key` presence.  */
static bool unpack_shard_header(const u8 * buf, sz file_size,
    sharded_decoding_options_t opt, const char * file_name,
    sharded_hv_result_t * res) {
  if (file_size < SHARD_HEADER_SIZE) return false;
  u8 vb = buf[4];
  bool has_b2b = (vb & SHARD_VERSION_BLAKE2B) != 0;
  bool has_key = (vb & SHARD_VERSION_KEYED) != 0;
  u8 base_ver = vb & SHARD_VERSION_MASK;
  if (base_ver != SHARD_VERSION) {
    if (!opt.quiet)
      xpar_fprintf(xpar_stderr, "Shard `%s': unsupported version %u.\n",
        file_name, base_ver);
    return false;
  }
  if (has_key && !has_b2b) {
    if (!opt.quiet)
      xpar_fprintf(xpar_stderr, "Shard `%s': invalid keyed-without-BLAKE2b mode.\n",
        file_name);
    return false;
  }
  sz hdr_size = has_b2b ? SHARD_HEADER_BLAKE2B_SIZE : SHARD_HEADER_SIZE;
  if (file_size < hdr_size) return false;
  if (has_key && !opt.auth_keylen)
    FATAL("Shard `%s' is authenticated; pass --auth=<keyfile>.", file_name);
  if (!has_key && opt.auth_keylen)
    FATAL("Shard `%s' is not authenticated; drop --auth.", file_name);
  res->dshards = buf[5];
  res->pshards = buf[6];
  res->shard_number = buf[7];
  /*  Accumulate into u64: on 32-bit `sz` shifting by >= 32 is UB, and
      on i386 the hardware wraps the shift count (uses the low 5 bits)
      so <<56 becomes <<24 and bytes 12..15 mirror bytes 8..11. Read
      into a u64, check for 32-bit overflow, then narrow.  */
  u64 ts = 0;
  Fi(8, ts |= ((u64) buf[8 + i]) << (56 - 8 * i))
  if (SIZEOF_SIZE_T == 4) {
    if (ts >> 32) {
      if (!opt.quiet)
        xpar_fprintf(xpar_stderr,
          "Shard `%s' is too large for 32-bit architectures.\n", file_name);
      return false;
    }
  }
  res->total_size = (sz) ts;
  res->auth = has_key;
  res->hdr_size = hdr_size;
  res->shard_size = file_size - hdr_size;
  const u8 * body = buf + hdr_size;
  if (has_b2b) {
#ifdef HAVE_BLAKE2B
    u8 tag[16];
    blake2b_state s;
    if (has_key) blake2b_init_key(&s, 16, opt.auth_key, opt.auth_keylen);
    else         blake2b_init(&s, 16);
    blake2b_update(&s, buf, 16);
    blake2b_update(&s, body, res->shard_size);
    blake2b_final(&s, tag, 16);
    if (xpar_memcmp(tag, buf + 16, 16) != 0) return false;
#else
    FATAL("Shard `%s' uses BLAKE2b but that support was disabled at "
          "configure time.", file_name);
#endif
  } else {
    Fi(4, res->crc |= ((u32) buf[16 + i]) << (24 - 8 * i))
    u32 c = crc32c_partial(0xFFFFFFFFL, (u8 *) buf, 16);
    c = crc32c_partial(c, (u8 *) body, res->shard_size) ^ 0xFFFFFFFFL;
    if (c != res->crc) return false;
  }
  return true;
}

static sharded_hv_result_t validate_shard_header(const char * file_name,
    sharded_decoding_options_t opt, const char * hdr) {
  sharded_hv_result_t res;  xpar_memset(&res, 0, sizeof(res));
  if (!opt.no_map) {
    #if defined(XPAR_ALLOW_MAPPING)
    xpar_mmap map = xpar_map(file_name);
    if (map.map) {
      if (map.size < SHARD_HEADER_SIZE || xpar_memcmp(map.map, hdr, 4)) {
        xpar_unmap(&map);  return res;
      }
      if (!unpack_shard_header(map.map, map.size, opt, file_name, &res)) {
        xpar_unmap(&map);  return res;
      }
      res.valid = true;  res.mapped = true;
      res.buf = map.map;   res.map = map;  return res;
    }
    #endif
  }
  xpar_file * in = xpar_open(file_name, XPAR_O_READ);
  if (!in) return res;
  xpar_seek(in, 0, XPAR_SEEK_END);
  sz size = xpar_tell(in);
  xpar_seek(in, 0, XPAR_SEEK_SET);
  if (size < SHARD_HEADER_SIZE) { xpar_close(in);  return res; }
  u8 * buffer = (u8 *) xpar_malloc(size);
  if (xpar_xread(in, buffer, size) != size) {
    xpar_free(buffer);  xpar_close(in);  return res;
  }
  xpar_close(in);
  if (xpar_memcmp(buffer, hdr, 4)) { xpar_free(buffer);  return res; }
  if (!unpack_shard_header(buffer, size, opt, file_name, &res)) {
    xpar_free(buffer);  return res;
  }
  res.buf = buffer; res.valid = true;  return res;
}

/*  Build a shard header into `dst` and compute the integrity tag over
    the header prefix + body. Returns bytes written (20 or 32).

      algo=INTEGRITY_CRC32C           -> 20 bytes, CRC32C.
      algo=INTEGRITY_BLAKE2B, keylen=0-> 32 bytes, unkeyed BLAKE2b-128.
      algo=INTEGRITY_BLAKE2B, keylen>0-> 32 bytes, keyed BLAKE2b-128 MAC.  */
static sz pack_shard_header(u8 dst[SHARD_HEADER_BLAKE2B_SIZE],
                            const char * magic,
                            u8 dshards, u8 pshards, u8 shard_number,
                            sz total_size, const u8 * body, sz body_len,
                            int algo, const u8 * key, sz keylen) {
  xpar_memcpy(dst, magic, 4);
  u8 vb = SHARD_VERSION;
  if (algo == INTEGRITY_BLAKE2B) {
    vb |= SHARD_VERSION_BLAKE2B;
    if (keylen) vb |= SHARD_VERSION_KEYED;
  } else if (keylen) {
    FATAL("Keyed MAC requested with a non-BLAKE2b integrity algorithm.");
  }
  dst[4] = vb;
  dst[5] = dshards;
  dst[6] = pshards;
  dst[7] = shard_number;
  /*  Widen to u64 before shifting: `total_size` is `sz` (size_t), which
      is 32-bit on i386; shifting by >= 32 is UB and on i386 hardware
      the shift count wraps, scrambling the big-endian encoding.  */
  { u64 ts = (u64) total_size;
    for (int i = 0; i < 8; i++) dst[8 + i] = (u8)(ts >> (56 - 8 * i)); }
  if (algo == INTEGRITY_BLAKE2B) {
#ifdef HAVE_BLAKE2B
    u8 tag[16];
    blake2b_state s;
    if (keylen) blake2b_init_key(&s, 16, key, keylen);
    else        blake2b_init(&s, 16);
    blake2b_update(&s, dst, 16);
    blake2b_update(&s, body, body_len);
    blake2b_final(&s, tag, 16);
    xpar_memcpy(dst + 16, tag, 16);
    return SHARD_HEADER_BLAKE2B_SIZE;
#else
    (void) body; (void) body_len; (void) key;
    FATAL("BLAKE2b requested but support was disabled at configure time.");
#endif
  }
  u32 c = crc32c_partial(0xFFFFFFFFL, dst, 16);
  c = crc32c_partial(c, (u8 *) body, body_len) ^ 0xFFFFFFFFL;
  for (int i = 0; i < 4; i++) dst[16 + i] = (u8)(c >> (24 - 8 * i));
  return SHARD_HEADER_SIZE;
}

#endif
